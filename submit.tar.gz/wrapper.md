# Project 3 Wrapper

### Q1: What advice would you give future students about debugging React components? {: #Q1}
FIXME


Q2a: How did your team design your React components to handle dynamic updates such as likes and comments?
Q2b: How did your team pass data between React components?

### Answer at least one of the two questions above {: #Q2}
FIXME


### Q3:  How did your team approach the division of work for this project? How did that experience go? {: #Q3}
FIXME